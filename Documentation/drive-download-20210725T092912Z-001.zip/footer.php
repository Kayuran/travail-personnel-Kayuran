    </div>
    <script src="bootstrap/vendor/jquery/jquery.min.js"></script>
    <script src="bootstrap/vendor/bootstrap/js/bootstrap.min.js"></script>
    <script src="bootstrap/vendor/metisMenu/metisMenu.min.js"></script>
    <script src="bootstrap/dist/js/sb-admin-2.js"></script>
  </body>
</html>
